Fazer antes de correr a APP

Data -> Kubernetes.mdf (dois cliques) -> Kubernetes.mdf (lado direito do rato) -> Propriedades -> Conection String (copiar)

Data -> Abrir - AppDbContext.cs -> Substituir pelo que copiou

___________________________________________________

